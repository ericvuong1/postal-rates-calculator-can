# postal-rates-calculator-can
Postal rates calculator for Canada.
ECSE 428 - Assignment B - Test Driven Development

# running the program
The executable folder contains instructions to execute the application on any platform, and also contains the .csv file for the postal code lookup table and the .py file to execute the program.

# referring to source code
The source code folder contains the postal-code-generator.csv file, test code 'test.py' and the script file 'postal_calc.py'. 

# documentation and screenshots
Assignment B.pdf contains all relevant documentations for assignment B


